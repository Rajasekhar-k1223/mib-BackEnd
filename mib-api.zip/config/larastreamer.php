<?php

    return [
        'basepath' => storage_path('app/uploads/'),
    ];
